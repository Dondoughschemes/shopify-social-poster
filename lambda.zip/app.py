import json

def lambda_handler(event, context):
    # This is just a placeholder response
    return {
        "statusCode": 200,
        "body": json.dumps("Hello from your Shopify-connected Lambda!")
    }
