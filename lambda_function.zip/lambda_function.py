import json
import requests
import os

VERIFY_TOKEN = "mysecrettoken123"  # Must match what you entered in the Facebook portal

def lambda_handler(event, context):
    # --- Webhook Verification Logic ---
    params = event.get('queryStringParameters', {}) or {}
    mode = params.get('hub.mode')
    token = params.get('hub.verify_token')
    challenge = params.get('hub.challenge')

    if mode == 'subscribe' and token == VERIFY_TOKEN:
        return {
            "statusCode": 200,
            "headers": {"Content-Type": "text/plain"},
            "body": challenge
        }
    # --- End Webhook Verification Logic ---

    print("Lambda function started...")

    # Extract product data from the event
    image_url = event.get('product_image_url')
    caption = event.get('caption', 'New product drop!')

    # Load access token from environment variables
    access_token = os.environ.get('IG_ACCESS_TOKEN')
    ig_account_id = '17841447131068769'  # Your Instagram Business Account ID

    print(f"Image URL: {image_url}")
    print(f"Caption: {caption}")
    print(f"Access token present: {bool(access_token)}")

    if not access_token or not image_url:
        print("Missing access token or image URL")
        return {
            "statusCode": 400,
            "body": json.dumps({"error": "Missing access token or image URL"})
        }

    # Step 1: Create media container
    create_media_url = f"https://graph.facebook.com/v18.0/{ig_account_id}/media"
    media_payload = {
        "image_url": image_url,
        "caption": caption,
        "access_token": access_token
    }

    print("Sending request to create media container...")
    media_response = requests.post(create_media_url, data=media_payload)
    media_result = media_response.json()
    print(f"Media creation response: {media_result}")

    if 'id' not in media_result:
        print("Failed to create media container.")
        return {
            "statusCode": 500,
            "body": json.dumps({"error": "Failed to create media container", "response": media_result})
        }

    container_id = media_result['id']

    # Step 2: Publish the media
    publish_url = f"https://graph.facebook.com/v18.0/{ig_account_id}/media_publish"
    publish_payload = {
        "creation_id": container_id,
        "access_token": access_token
    }

    print("Sending request to publish media...")
    publish_response = requests.post(publish_url, data=publish_payload)
    publish_result = publish_response.json()
    print(f"Media publish response: {publish_result}")

    return {
        "statusCode": 200,
        "body": json.dumps({
            "message": "Post published to Instagram",
            "result": publish_result
        })
    }
