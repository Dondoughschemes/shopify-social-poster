import json

def lambda_handler(event, context):
    body = json.loads(event["body"])
    
    title = body.get("title")
    handle = body.get("handle")
    image_url = body.get("image", {}).get("src", "")
    product_url = f"https://your-store-name.myshopify.com/products/{handle}"

    message = f"🚨 New Product Alert: {title} is now available!\n{product_url}"

    # Placeholder for actual posting
    post_to_twitter(message, image_url)
    post_to_instagram(message, image_url)

    return {
        "statusCode": 200,
        "body": json.dumps("Social media post triggered!")
    }

def post_to_twitter(message, image_url):
    print(f"Posting to Twitter: {message} (Image: {image_url})")

def post_to_instagram(message, image_url):
    print(f"Posting to Instagram: {message} (Image: {image_url})")
